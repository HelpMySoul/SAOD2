#pragma once
void string_copy(char* t, char* str);
int len(const char* s);
int compare(const char* s, const char* t);