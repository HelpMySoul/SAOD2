#pragma once
void Swap(int& a, int& b);

