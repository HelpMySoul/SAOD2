#pragma once
int Plus(int a, int b);